module.exports = {
    APP_NAME: 'navi'
};