// api routes tests
// const request = require('supertest');

// const app = require('../app');

// describe('API Routes', function() {
//   describe('GET /api/users/current', function() {
//     it('does not send a user if not logged in', async (done) => {
//       try {
//         const res = await request(app)
//           .get('/api/users/current')
//           .expect(401);
//         expect(res).to.be.an('object').notify(done);
//       } catch (error) {
//         throw error;
//       }
//     });
//   });
// });
